const UNIT_CONVERT = /(?<quantity>\d+) (?<base>.*)(?:s)? (?:in|to) (?<target>.*)(?:s)?/;
const FUEL_TRAVEL = /fuel to travel (?<quantity>\d+) mile(?:s)?/;
const SURFACE_AREA = /surface area of field with diameter (?<value>\d+).*/;

eel.expose(read)

function update_response(text) {
	const RESPONSE = document.getElementById("response");
	RESPONSE.innerText = text;
}

function submit() {
	const TEXTBOX = document.getElementById("box");
	const { value: VALUE } = TEXTBOX;

	// unit conversion
	if (UNIT_CONVERT.test(VALUE)) {
		let { quantity, target, base } = UNIT_CONVERT.exec(VALUE).groups;

		try {
			quantity = parseFloat(quantity);
		} catch {
			update_response("Quantity is not a valid number");
		}

		eel.convert_units(base, target, quantity)().then(update_response);
	} else if (FUEL_TRAVEL.test(VALUE)) {
		let { quantity } = FUEL_TRAVEL.exec(VALUE).groups;

		try {
			quantity = parseFloat(quantity);
		} catch {
			update_response("Quantity is not a valid number");
		}

		eel.calculate_fuel(quantity)().then(update_response);
	} else if (SURFACE_AREA.test(VALUE)) {
		let { value } = SURFACE_AREA.exec(VALUE).groups;

		try {
			value = parseFloat(value);
		} catch {
			update_response("Diameter is not a valid number");
		}

		eel.surface_area(value)().then(update_response);
	}
}

function save() {
	const RESPONSE = document.getElementById("response");
	const SAVE_RESPONSE = document.getElementById("save_response");
	
	eel.save(RESPONSE.innerText)().then(file_id => {
		SAVE_RESPONSE.innerText = `You can find the response at out/${file_id}.txt`;

		setTimeout(() => SAVE_RESPONSE.innerText = "", 5000);
	});
}